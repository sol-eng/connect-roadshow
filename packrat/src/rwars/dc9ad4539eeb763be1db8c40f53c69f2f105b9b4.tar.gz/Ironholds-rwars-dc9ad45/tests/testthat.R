library(testthat)
library(rwars)

test_check("rwars")
