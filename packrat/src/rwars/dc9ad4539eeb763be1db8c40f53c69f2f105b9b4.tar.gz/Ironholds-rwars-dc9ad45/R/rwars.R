#'@title Star Wars API client library
#'@description A package connecting R to the Star Wars API
#'@name rwars
#'@docType package
#'@aliases rwars rwars-package
NULL