# Setup

## Platform

|setting  |value                        |
|:--------|:----------------------------|
|version  |R version 3.3.0 (2016-05-03) |
|system   |x86_64, darwin13.4.0         |
|ui       |RStudio (0.99.1223)          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|tz       |America/Chicago              |
|date     |2016-06-17                   |

## Packages

|package  |*  |version    |date       |source                           |
|:--------|:--|:----------|:----------|:--------------------------------|
|BH       |   |1.60.0-2   |2016-05-07 |CRAN (R 3.3.0)                   |
|covr     |   |2.0.1      |2016-04-06 |CRAN (R 3.3.0)                   |
|dplyr    |   |0.4.3      |2015-09-01 |cran (@0.4.3)                    |
|lazyeval |   |0.2.0.9000 |2016-06-17 |Github (hadley/lazyeval@c155c3d) |
|magrittr |   |1.5        |2014-11-22 |CRAN (R 3.3.0)                   |
|purrr    |*  |0.2.1.9000 |2016-06-17 |local (hadley/purrr@3a3249e)     |
|Rcpp     |   |0.12.5     |2016-05-14 |CRAN (R 3.3.0)                   |
|testthat |*  |1.0.2.9000 |2016-06-16 |Github (hadley/testthat@d3e20b9) |

# Check results
0 packages with problems


