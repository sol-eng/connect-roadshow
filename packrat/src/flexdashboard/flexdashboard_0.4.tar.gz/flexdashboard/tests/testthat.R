library(testthat)
test_check("flexdashboard")

