
named <- function(x) {
  set_names(x, names2(x))
}
